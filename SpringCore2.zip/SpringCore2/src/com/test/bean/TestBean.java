package com.test.bean;

public class TestBean implements Test {
	public void display()
	{
		System.out.println("Hello Spring");
	}
}
