package com.test.bean;

import java.util.ResourceBundle;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

@SuppressWarnings("unused")
public class TestClient {

	public static void main(String[] args) {
		 Resource resource=new FileSystemResource("TestCfg.xml");  
		    BeanFactory factory=new XmlBeanFactory(resource);
		    Test t=(Test)factory.getBean("tb");
	      		t.display();
	      		
	      		
	      		 System.out.println("------------2nd day ka program----------------");
	      		 
		    Employee emp = (Employee)factory.getBean("emp");
		    System.out.println(emp);
		    
		    System.out.println("------------by Get methods----------------");
		    
		    System.out.println( " Employee Number : " + emp.getEmpNo() + "\nEmployee Name : " +emp.getEmpNmae() + "\nEmployee Mobile  Number : " +emp.getEmpMobileNo() + "\nEmployee Email : " +emp.getEmpEmail());

		    
	}

}