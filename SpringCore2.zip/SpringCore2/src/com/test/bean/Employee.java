package com.test.bean;

public class Employee {
    private Integer empNo;
    private String empNmae;
    private String empMobileNo;
    private String empEmail;
	public Integer getEmpNo() {
		return empNo;
	}
	public void setEmpNo(Integer empNo) {
		this.empNo = empNo;
	}
	public String getEmpNmae() {
		return empNmae;
	}
	public void setEmpNmae(String empNmae) {
		this.empNmae = empNmae;
	}
	public String getEmpMobileNo() {
		return empMobileNo;
	}
	public void setEmpMobileNo(String empMobileNo) {
		this.empMobileNo = empMobileNo;
	}
	public String getEmpEmail() {
		return empEmail;
	}
	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	@Override
	public String toString() {
		return "Employee [empNo=" + empNo + ", empNmae=" + empNmae + ", empMobileNo=" + empMobileNo + ", empEmail="
				+ empEmail + "]";
	}
    
    
    
    
}
